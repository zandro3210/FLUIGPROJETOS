function afterProcessCreate(processId){
	hAPI.setCardValue("nrSolicitacao", processId);
}