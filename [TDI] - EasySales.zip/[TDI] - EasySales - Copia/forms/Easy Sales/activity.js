var Activity = {
	ZERO: 0,
	INICIO: 1,
	PREENCHER_QUESTIONARIO: 83,
	MODIFICAR: 82,
	RELATORIO: 104,
	FIM: 72
}

var PRD = "https://187.94.57.182";
var HML = "http://172.24.52.14:8091";
var SERVER = HML;
